TERMUX_SUBPKG_INCLUDE="lib/libharfbuzz-icu*"
TERMUX_SUBPKG_DESCRIPTION="OpenType text shaping engine ICU backend"
TERMUX_SUBPKG_DEPENDS="libicu"
