TERMUX_SUBPKG_INCLUDE="lib/libdw.a"
TERMUX_SUBPKG_DESCRIPTION="Static library to read DWARF information"
TERMUX_SUBPKG_DEPENDS="libdw"
