TERMUX_SUBPKG_DESCRIPTION="apt-ftparchive is the command line tool that generates the index files that APT uses to access a distribution source"
TERMUX_SUBPKG_DEPENDS="libdb"
TERMUX_SUBPKG_INCLUDE="
bin/apt-ftparchive
"
