TERMUX_SUBPKG_INCLUDE="lib/libasm.a"
TERMUX_SUBPKG_DESCRIPTION="Static library to assemble and disassemble instructions"
TERMUX_SUBPKG_DEPENDS="libasm"
