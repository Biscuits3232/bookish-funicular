TERMUX_SUBPKG_DESCRIPTION="Additional utilities for Geth (like abigen, bootnode, evm, puppeth)"

TERMUX_SUBPKG_INCLUDE="
bin/abigen
bin/bootnode
bin/ethkey
bin/evm
bin/rlpdump
bin/swarm
bin/puppeth"
