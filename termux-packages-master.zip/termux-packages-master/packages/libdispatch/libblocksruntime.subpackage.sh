TERMUX_SUBPKG_INCLUDE="include/Block.h lib/libBlocksRuntime.so"
TERMUX_SUBPKG_DESCRIPTION="LLVM Blocks runtime library"
