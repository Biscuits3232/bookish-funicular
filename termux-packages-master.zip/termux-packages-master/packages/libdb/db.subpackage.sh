TERMUX_SUBPKG_INCLUDE="bin/"
TERMUX_SUBPKG_DESCRIPTION="The Berkeley DB embedded database system"
