TERMUX_PKG_HOMEPAGE=https://jpmens.net/2016/03/05/a-shell-command-to-create-json-jo/
TERMUX_PKG_DESCRIPTION="JSON output from a shell"
TERMUX_PKG_LICENSE="GPL-2.0"
TERMUX_PKG_MAINTAINER="Rabby Sheikh @xploitednoob"
TERMUX_PKG_VERSION=1.4
TERMUX_PKG_SRCURL=https://github.com/jpmens/jo/releases/download/${TERMUX_PKG_VERSION}/jo-${TERMUX_PKG_VERSION}.tar.gz
TERMUX_PKG_SHA256=24c64d2eb863900947f58f32b502c95fec8f086105fd31151b91f54b7b5256a2
