TERMUX_PKG_HOMEPAGE=https://github.com/sharkdp/hexyl
TERMUX_PKG_DESCRIPTION="A command-line hex viewer"
TERMUX_PKG_LICENSE="Apache-2.0"
TERMUX_PKG_MAINTAINER="@termux"
TERMUX_PKG_VERSION=0.8.0
TERMUX_PKG_SRCURL=https://github.com/sharkdp/hexyl/archive/v$TERMUX_PKG_VERSION.tar.gz
TERMUX_PKG_SHA256=b2e69b4ca694afd580c7ce22ab83a207174d2bbc9dabbad020fee4a98a1205be
TERMUX_PKG_BUILD_IN_SRC=true
