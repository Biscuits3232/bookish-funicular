TERMUX_SUBPKG_INCLUDE="bin/curl share/man/man1/curl.1.gz"
TERMUX_SUBPKG_DESCRIPTION="Command line tool for transferring data with URL syntax"
TERMUX_SUBPKG_ESSENTIAL=true
